Programming Assignment #1: Echo Server
Student: Demonna Wade
Class: 2:00 pm T,R

To Do:

I did not modify the make file to run differently that it was desgined. The only this that
is different is the inclusion of two files (log.h and log.cc). These files make a simple
logger that I used for this assignment. The boost logging libraries were a little too 
confusing for me to understand in the time allocated for this assignment. 
